//
// Created by yuval on 27/11/2019.
//
#include <map>
#include <iostream>
#include <string>
#include <string.h>
#include <queue>
#include <stack>
#include <ctype.h>
#include <stdlib.h>
#include <fstream>
#include <functional>
#include <list>
#include <unordered_map>
#include<iterator>
using namespace std;

#ifndef EX02_EX2_H
#define EX02_EX2_H
template <typename T>
class CacheManager
{
    //the capacity of the cache mamory
    int capacity;
    //list of the all the object. the string is id and T is the object
     list<pair<string,T>>myList;
     //cache memory that contain pointer to each itartor of each object
    unordered_map<string, typename list<pair<string,T>>::iterator> cacheMemory;

public:
    CacheManager(int _capacity): capacity(_capacity){}
    CacheManager() {}; // default constructor

    void insert(string key, T obj) {
        // the object not present in cache
        if (cacheMemory.find(key) == cacheMemory.end()) {
            // cache is full
            unsigned int cap;
            cap = abs(capacity);
            if (myList.size() == cap) {
                // delete least recently used element
                pair<string,T> last = myList.back();
                // Pops the last elmeent
                myList.pop_back();
                // Erase the last element
                cacheMemory.erase(last.first);
            }

            //check if this object have file
            ifstream file;
            file.open(T::class_name+key, ios::binary);
            if(file) {
                // the file of this key already exists, no need to increase the counter
                // update the file which exists
                file.close();
                std::string str = T::class_name+key;
                const char * c = str.c_str();
                // delete the exist file
                const int result = remove(c);
                if( result != 0 ){
                   throw ("cant delete file");
                }

               // create new file for thr object
                ofstream myfile;
                myfile.open(T::class_name+key, ios::binary);
                if(myfile) {
                    // write the object into the file
                    myfile.write((char *) &obj, sizeof(obj));
                    myfile.close();
                } else{
                    throw ("cant open file" + T::class_name+key);
                }
                file.close();
            } else {
                //  the file of this key doesnt exists
                //create new file for this obj
                ofstream myfile;
                myfile.open(T::class_name+key, ios::binary);
                if(myfile) {
                    myfile.write((char *) &obj, sizeof(obj));
                    myfile.close();
                } else {
                    throw ("cant open file" + T::class_name+key);
                }
            }


        }
            // the object in cache
        else {
            // erase the object from the list
            myList.erase(cacheMemory[key]);
            // if the file of this object exists, it will be deleting
            ifstream file2;
            file2.open(T::class_name+key, ios::binary);
            if(file2) {
                file2.close();
                std::string str = T::class_name + key;
                const char *c = str.c_str();
                // delete the exist file
                const int result = remove(c);
                if (result != 0) {
                    throw ("cant delete file");
                }
            }
                // create new file for thr object
                ofstream myfile2;
                myfile2.open(T::class_name+key, ios::binary);
                if(myfile2) {
                    // write the object into the file
                    myfile2.write((char *) &obj, sizeof(obj));
                    myfile2.close();
                } else{
                    throw ("cant open file" + T::class_name+key);
                }
        }

        // update reference
        pair <string,T> newP;
        newP.first = key;
        newP.second = obj;
        myList.push_front(newP);
        //insert new pair to map - because the key dosent exists in cache memory
        cacheMemory[key] = myList.begin();
    };

    T get(string key) {
        // this key doesnt exists in cache memory
        if (cacheMemory.find(key) == cacheMemory.end()) {
            //the key doesnt exists in the cache memory, checking if it is exists in file system
            ifstream myfile;
            // trying to open the file of this key
            myfile.open(T::class_name + key, ios::in);
            if (myfile) {
                // the key exists in file but not on cache memory
                T obj;
                myfile.read((char *) &obj, sizeof(obj));
                myfile.close();
                // insert the key to cache memory
                insert(key, obj);
                return obj;
            } else {
                //the key doest exists both in cache memory and file system
                throw ("an error");
            }

        } else {
            // the key exists in cache memory
            auto cacheItem = this->cacheMemory.find(key);
            T obj = cacheItem->second->second;
            // insere again the key to cache memory to keep the lru algorithem
            insertToCacheMemory(key, obj);
            return obj;
        }
    };

    void foreach(const function<void(T&)> func) {
        for (pair<string,T> it : myList){
            // make some function on the cache memory
            func(it.second);
        }
    };

    void insertToCacheMemory(string key, T obj)
    {
        // insert the key only to cache memory and not to file system
        // not present in cache
        if (cacheMemory.find(key) == cacheMemory.end()) {
            // cache is full
            unsigned int c;
            c = abs(capacity);
            if (this->myList.size() == c) {
                pair<string,T> last = myList.back();
                myList.pop_back();
                cacheMemory.erase(last.first);
            }
        }

            //the key exsits in cache
        else{
            myList.erase(cacheMemory[key]);
        }
        pair <string,T> newP;
        newP.first = key;
        newP.second = obj;
        // push the new object to the front of the list
        myList.push_front(newP);
        // insert the key to cache memory
        cacheMemory[key] = myList.begin();
    };
};


class ex2 {

};


#endif //EX02_EX2_H
