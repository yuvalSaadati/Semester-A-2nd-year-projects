//
// Created by yuval on 11/11/2019.
//

#ifndef EX_111_EXPRESSION_H
#define EX_111_EXPRESSION_H
using namespace std;
/**
 * Expression Interface
 */
class Expression {

public:
    virtual double calculate() = 0;
    virtual ~Expression() {}
};

#endif //EX_111_EXPRESSION_H
