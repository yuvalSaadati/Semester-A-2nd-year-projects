//
// Created by yuval on 27/11/2019.
//
#include <map>
#include <iostream>
#include <string>
#include <string.h>
#include <queue>
#include <stack>
#include <ctype.h>
#include <stdlib.h>
#include <fstream>

using namespace std;

#ifndef EX02_EX2_H
#define EX02_EX2_H
template <typename T>
class CacheManager
{
    queue <T> studentQueue;
    int capacity;
    map<string,T> cacheMemory;
public:
    CacheManager(int _capacity): capacity(_capacity){}
    CacheManager() {}; // default constructor

    void insert(string key, T obj) {
        studentQueue.push(obj);

        map<string,T> it = this->cacheMemory.find(key);


        if (capacity > 0) {
            if (it != this->cacheMemory.end()) {
                // this key exists and we update the data
                this->cacheMemory[key] = obj;
                ifstream myfile;
                myfile.open(key, ios::trunc);
                myfile.close();
                ofstream newMyfile;
                newMyfile.open(key);
                newMyfile.write((char *) &obj, sizeof(obj));
            } else {
                this->cacheMemory[key] = obj;
                ofstream myfile;
                myfile.open(key);
                myfile.write((char *) &obj, sizeof(obj));
            }
        }

    };
    T get(string key) {
        map<string, T> it = this->cacheMemory.find(key);
        if (it != this->cacheMemory.end()) {
            this->studentQueue.erase(std::remove(this->studentQueue.begin(), this->studentQueue.end(),
                                                 it->second), this->studentQueue.end());
            this->studentQueue.push( it->second);
            return this->cacheMemory[key];
        } else {
            throw ("an error");
        }
    };


};

class ex2 {

};


#endif //EX02_EX2_H
