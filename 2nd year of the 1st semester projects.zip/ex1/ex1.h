//
// Created by yuval on 11/11/2019.
//
#include <map>
#include <iostream>
#include "Expression.h"
using namespace std;
#ifndef EX_1_EX1_H
#define EX_1_EX1_H
class ex1 {

};

class Variable : public Expression{
    string valName;
    double myValue;
public:
    Variable (string name, double x):valName(name), myValue(x) {}
    double calculate();
    Variable& operator++();
    Variable& operator++(int);
    Variable& operator--();
    Variable& operator--(int);
    Variable& operator+=(double x);
    Variable& operator-=(double x);
    virtual ~Variable() {}

};

class BinaryOperator : public Expression  {
protected:
    Expression* left;
    Expression* right;
    virtual ~BinaryOperator() {
        delete left;
        delete right;
    }
};

class UnaryOperator : public Expression  {
protected:
    Expression* expr;
    virtual ~UnaryOperator() {
        delete expr;
    }
};

class Value : public Expression {
    double value;
public:
    Value (double x): value(x) {}
    double calculate() { return  this->value; }
    virtual ~Value() {}

};

class Plus : public BinaryOperator {
public:
    Plus(Expression* l, Expression* r) {
        this->left = l;
        this->right = r;
    }
    double calculate();
    virtual ~Plus() {}

};

class Minus : public BinaryOperator {
public:
    Minus(Expression* l, Expression* r) {
        this->left = l;
        this->right = r;
    }
    double calculate();
    virtual ~Minus() {}

};

class Mul : public BinaryOperator {
public:
    Mul(Expression* l, Expression* r) {
        this->left = l;
        this->right = r;
    }
    double calculate();
    virtual ~Mul() {}

};

class Div : public BinaryOperator {
public:
    Div(Expression* l, Expression* r) {
        this->left = l;
        this->right = r;
    }
    double calculate();
    virtual ~Div() {}

};

class UPlus : public UnaryOperator {
public:
    UPlus(Expression* e) {
        this->expr = e;
    }
    double calculate();
    virtual ~UPlus() {}

};

class UMinus : public UnaryOperator {
public:
    UMinus(Expression* e) {
        this->expr = e;
    }
    double calculate() override;
    virtual ~UMinus() {}

};
class Interpreter{
public:
    map<string,string> variableMap;
    Interpreter() {}
    Expression * interpret(string expressionString);
    void setVariables(string variables);
    bool isnumber(string s);
    virtual ~Interpreter() {}
};
#endif //EX_111_EX1_H
